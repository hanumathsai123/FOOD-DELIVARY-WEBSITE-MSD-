const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const ordersFile = path.join(DATA_DIR, 'orders.json');
const productsFile = path.join(DATA_DIR, 'products.json');
const usersFile = path.join(DATA_DIR, 'users.json');

if (!fs.existsSync(ordersFile)) fs.writeFileSync(ordersFile, '[]');
if (!fs.existsSync(productsFile)) fs.writeFileSync(productsFile, '[]');
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');

function readJSON(file){
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, file))); } catch(e){ return []; }
}
function writeJSON(file, data){
  fs.writeFileSync(path.join(DATA_DIR, file), JSON.stringify(data, null, 2));
}

// Products endpoints (simple)
app.get('/api/products', (req, res) => {
  const p = readJSON('products.json');
  res.json(p);
});
app.post('/api/products', (req, res) => {
  const products = readJSON('products.json');
  const prod = { id: Date.now().toString(), ...req.body };
  products.push(prod);
  writeJSON('products.json', products);
  res.json(prod);
});

// Orders
app.get('/api/orders', (req, res) => {
  const orders = readJSON('orders.json');
  res.json(orders);
});
app.post('/api/orders', (req, res) => {
  const orders = readJSON('orders.json');
  const { items, total, customer, meta } = req.body;
  const order = { id: Date.now().toString(), items: items||[], total: total||0, customer: customer||null, meta: meta||null, createdAt: new Date().toISOString() };
  orders.push(order);
  writeJSON('orders.json', orders);
  res.json({ id: order.id, message: 'Order saved' });
});

// Simple auth (register/login) - minimal, for demo only
app.post('/api/auth/register', (req, res) => {
  const users = readJSON('users.json');
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Missing fields' });
  if (users.find(u=>u.email===email)) return res.status(400).json({ message: 'Email exists' });
  const user = { id: Date.now().toString(), name, email, password };
  users.push(user);
  writeJSON('users.json', users);
  res.json({ id: user.id, name: user.name, email: user.email });
});
app.post('/api/auth/login', (req, res) => {
  const users = readJSON('users.json');
  const { email, password } = req.body;
  const user = users.find(u=>u.email===email && u.password===password);
  if (!user) return res.status(400).json({ message: 'Invalid credentials' });
  res.json({ id: user.id, name: user.name, email: user.email });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log(`✅ Backend running at http://localhost:${PORT}`));
