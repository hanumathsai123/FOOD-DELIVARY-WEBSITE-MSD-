const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { readJSON, writeJSON } = require('../db');
const { v4: uuidv4 } = require('uuid');

const USERS_FILE = 'users.json';
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

// Register
router.post('/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: 'Missing fields' });
  const users = readJSON(USERS_FILE);
  if (users.find(u => u.email === email)) return res.status(400).json({ message: 'Email already exists' });
  const hashed = bcrypt.hashSync(password, 8);
  const user = { id: uuidv4(), name, email, password: hashed };
  users.push(user);
  writeJSON(USERS_FILE, users);
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

// Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = readJSON(USERS_FILE);
  const user = users.find(u => u.email === email);
  if (!user) return res.status(400).json({ message: 'Invalid credentials' });
  const ok = bcrypt.compareSync(password, user.password);
  if (!ok) return res.status(400).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

module.exports = router;


/* BACKEND_HELPER_INJECTED */
const API_BASE = "http://localhost:5000/api";

function saveToken(token){
  localStorage.setItem('msd_token', token);
}
function getToken(){
  return localStorage.getItem('msd_token');
}
function authHeaders(){
  const t = getToken();
  return t ? { 'Authorization': 'Bearer ' + t } : {};
}
// helper to POST JSON with auth
async function postJSON(url, data){
  const resp = await fetch(url, {
    method: 'POST',
    headers: Object.assign({'Content-Type':'application/json'}, authHeaders()),
    body: JSON.stringify(data)
  });
  return resp.json();
}
// helper to GET with auth
async function getJSON(url){
  const resp = await fetch(url, { headers: Object.assign({}, authHeaders()) });
  return resp.json();
}
