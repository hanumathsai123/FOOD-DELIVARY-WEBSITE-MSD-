const express = require('express');
const router = express.Router();
const { readJSON, writeJSON } = require('../db');
const { v4: uuidv4 } = require('uuid');

// List products
router.get('/', (req, res) => {
  const products = readJSON('products.json');
  res.json(products);
});

// Get single
router.get('/:id', (req, res) => {
  const products = readJSON('products.json');
  const p = products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

// Create product
router.post('/', (req, res) => {
  const products = readJSON('products.json');
  const { title, description, price, available } = req.body;
  const prod = { id: uuidv4(), title, description: description||'', price: price||0, available: available===undefined?true:available };
  products.push(prod);
  writeJSON('products.json', products);
  res.json(prod);
});

// Update
router.put('/:id', (req, res) => {
  const products = readJSON('products.json');
  const idx = products.findIndex(x => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Not found' });
  const updated = { ...products[idx], ...req.body };
  products[idx] = updated;
  writeJSON('products.json', products);
  res.json(updated);
});

// Delete
router.delete('/:id', (req, res) => {
  let products = readJSON('products.json');
  const before = products.length;
  products = products.filter(x => x.id !== req.params.id);
  writeJSON('products.json', products);
  res.json({ deleted: before - products.length });
});

module.exports = router;


/* BACKEND_HELPER_INJECTED */
const API_BASE = "http://localhost:5000/api";

function saveToken(token){
  localStorage.setItem('msd_token', token);
}
function getToken(){
  return localStorage.getItem('msd_token');
}
function authHeaders(){
  const t = getToken();
  return t ? { 'Authorization': 'Bearer ' + t } : {};
}
// helper to POST JSON with auth
async function postJSON(url, data){
  const resp = await fetch(url, {
    method: 'POST',
    headers: Object.assign({'Content-Type':'application/json'}, authHeaders()),
    body: JSON.stringify(data)
  });
  return resp.json();
}
// helper to GET with auth
async function getJSON(url){
  const resp = await fetch(url, { headers: Object.assign({}, authHeaders()) });
  return resp.json();
}
