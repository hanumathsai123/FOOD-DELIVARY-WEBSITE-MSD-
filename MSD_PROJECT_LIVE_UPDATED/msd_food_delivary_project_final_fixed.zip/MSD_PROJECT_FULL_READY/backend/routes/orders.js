const express = require('express');
const router = express.Router();
const { readJSON, writeJSON } = require('../db');
const { v4: uuidv4 } = require('uuid');

// Create order
router.post('/', (req, res) => {
  const orders = readJSON('orders.json');
  const { items, total, customer } = req.body;
  if (!items || !Array.isArray(items)) return res.status(400).json({ message: 'Invalid items' });
  const order = { id: uuidv4(), items, total: total||0, customer: customer||null, createdAt: new Date().toISOString() };
  orders.push(order);
  writeJSON('orders.json', orders);
  res.json(order);
});

// List orders
router.get('/', (req, res) => {
  const orders = readJSON('orders.json');
  res.json(orders);
});

// Get one
router.get('/:id', (req, res) => {
  const orders = readJSON('orders.json');
  const o = orders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({ message: 'Not found' });
  res.json(o);
});

module.exports = router;


/* BACKEND_HELPER_INJECTED */
const API_BASE = "http://localhost:5000/api";

function saveToken(token){
  localStorage.setItem('msd_token', token);
}
function getToken(){
  return localStorage.getItem('msd_token');
}
function authHeaders(){
  const t = getToken();
  return t ? { 'Authorization': 'Bearer ' + t } : {};
}
// helper to POST JSON with auth
async function postJSON(url, data){
  const resp = await fetch(url, {
    method: 'POST',
    headers: Object.assign({'Content-Type':'application/json'}, authHeaders()),
    body: JSON.stringify(data)
  });
  return resp.json();
}
// helper to GET with auth
async function getJSON(url){
  const resp = await fetch(url, { headers: Object.assign({}, authHeaders()) });
  return resp.json();
}
