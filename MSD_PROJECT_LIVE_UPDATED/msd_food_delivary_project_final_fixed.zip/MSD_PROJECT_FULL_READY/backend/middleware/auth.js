const jwt = require('jsonwebtoken');
const secret = process.env.JWT_SECRET || 'change_this_secret';

function auth(req, res, next) {
  const token = req.headers['authorization'] && req.headers['authorization'].split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token provided' });
  try {
    const decoded = jwt.verify(token, secret);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

module.exports = auth;


/* BACKEND_HELPER_INJECTED */
const API_BASE = "http://localhost:5000/api";

function saveToken(token){
  localStorage.setItem('msd_token', token);
}
function getToken(){
  return localStorage.getItem('msd_token');
}
function authHeaders(){
  const t = getToken();
  return t ? { 'Authorization': 'Bearer ' + t } : {};
}
// helper to POST JSON with auth
async function postJSON(url, data){
  const resp = await fetch(url, {
    method: 'POST',
    headers: Object.assign({'Content-Type':'application/json'}, authHeaders()),
    body: JSON.stringify(data)
  });
  return resp.json();
}
// helper to GET with auth
async function getJSON(url){
  const resp = await fetch(url, { headers: Object.assign({}, authHeaders()) });
  return resp.json();
}
