# MSD Project Backend (added by ChatGPT)

This is a simple Node + Express backend that stores data in JSON files (no external DB).
Routes:
- POST /api/auth/register  -> { name, email, password }
- POST /api/auth/login     -> { email, password }
- GET  /api/products
- POST /api/products
- PUT  /api/products/:id
- DELETE /api/products/:id
- GET  /api/orders
- POST /api/orders

To run:
1. cd backend
2. npm install
3. npm run dev   (or npm start)

Notes:
- JWT secret is `change_this_secret` by default. Set env JWT_SECRET in production.
- This backend is intended for local/demo use and quick submission. For production use, migrate to a real database.
