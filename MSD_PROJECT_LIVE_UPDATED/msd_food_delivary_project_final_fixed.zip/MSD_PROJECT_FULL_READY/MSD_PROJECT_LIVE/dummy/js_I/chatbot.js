
function setupChatbot(){
  const chatBtn = document.getElementById('chatBtn');
  const chatBox = document.getElementById('chatBox');
  const chatSend = document.getElementById('chatSend');
  const chatInput = document.getElementById('chatInput');
  const chatBody = document.getElementById('chatBody');
  if(!chatBtn) return;
  chatBtn.addEventListener('click', ()=> chatBox.classList.toggle('open'));
  chatSend.addEventListener('click', ()=>{
    const q = chatInput.value.trim(); if(!q) return;
    const el = document.createElement('div'); el.innerHTML = `<b>You:</b> ${q}`; chatBody.appendChild(el);
    setTimeout(()=>{ const r = document.createElement('div'); r.innerHTML = `<b>Bot:</b> Try Veg Thali + Masala Chai — ₹248`; chatBody.appendChild(r); chatBody.scrollTop = chatBody.scrollHeight; },700);
    chatInput.value='';
  });
}
document.addEventListener('DOMContentLoaded', setupChatbot);


/* BACKEND_HELPER_INJECTED */
const API_BASE = "http://localhost:5000/api";

function saveToken(token){
  localStorage.setItem('msd_token', token);
}
function getToken(){
  return localStorage.getItem('msd_token');
}
function authHeaders(){
  const t = getToken();
  return t ? { 'Authorization': 'Bearer ' + t } : {};
}
// helper to POST JSON with auth
async function postJSON(url, data){
  const resp = await fetch(url, {
    method: 'POST',
    headers: Object.assign({'Content-Type':'application/json'}, authHeaders()),
    body: JSON.stringify(data)
  });
  return resp.json();
}
// helper to GET with auth
async function getJSON(url){
  const resp = await fetch(url, { headers: Object.assign({}, authHeaders()) });
  return resp.json();
}
